#include <REG51.H>
unsigned char key(void)
{
    unsigned char i;
    for(i = 0; i <6; i++) 
    {
        if(~P1 & (1 << i))
        {
            return i+1;
        }
    }
    return 0;
}

unsigned char key_S(void)
{
    unsigned char ago, i;
    ago = key();
    for(i = 10; i; i--)
    {
        if(key() != ago)
		{
			return 0;
		}
    }
    return ago;
}

void delay()
{
    unsigned char i;
    for(i = 100; i; i--);
}

void delay_S(void)
{
    unsigned int i;
    for(i = 25000; i; i-- );
}

void show(unsigned char num)
{
    unsigned char tab[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x88,0x83,0xc6,0xa1,0x86,0x8e};
    unsigned char tens, units;
    tens = num / 10 % 10;
    units = num % 10;
    P1 = P1 & 0x3f;
    P1 = P1 | 0x40;
    P0 = tab[tens];
    delay();
    P1 = P1 & 0x3f;
    P1 = P1 | 0x80;
    P0 = tab[units];
    delay();
    P1 = P1 & 0x3f;
}

void init_T0()
{
    TMOD = 0x02;
    TH0 = 0x38;
    TL0 = 0x38;
    TR0 = 1;
	EA = 1;
	ET0 = 1;
}

unsigned char time = 30;
unsigned int count = 5000;
void main(void)
{
    unsigned char result, tmp;
    while(key_S() != 5)
    {
        show(time);
    }
    tmp = key_S();
    init_T0();
    delay_S();
    while(!result)
    {
        show(time);
		result = key_S();
	}

    while(result)
    {
        show(result);
        if(key_S() == 6)
        {
            result = 0;
            time = 30;
			TR0 = 0;
            break;
        }
    }
}

void timer0(void) interrupt 1
{
    count--;
    if(!count && time)
    {
	    count = 5000;
        time = time -1;
    }
}