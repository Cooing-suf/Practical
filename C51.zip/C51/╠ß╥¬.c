AT89C51
4抢答按钮，1控制
1双位数码管



int set(void)
{
    引脚-》位号;
    引脚-》开始；
    引脚-》复位；
    return 0；
}

int show(int time)
{
    显示数字； 
}

void timer0() interrupt 1
{
   time 倒计时; 
}

main()
{
    开始？向下：显示时间；
    查询，显秒；
    确认，显示结果
}